#!/usr/bin/env python3
from pathlib import Path
from textwrap import dedent

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

def write(path: str, content: str) -> None:
    p = ROOT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")

def replace_once(path: str, old: str, new: str) -> None:
    text = read(path)
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{path}: expected one exact match, found {count}")
    write(path, text.replace(old, new, 1))

def replace_count(path: str, old: str, new: str, expected: int) -> None:
    text = read(path)
    count = text.count(old)
    if count != expected:
        raise SystemExit(f"{path}: expected {expected} exact matches, found {count}")
    write(path, text.replace(old, new))

# 1. Fix the PressWarden-only `database status` pseudo-action so preflight
# checks a real LiteSpeed database subcommand rather than asking WP-CLI for
# nonexistent `litespeed-database status` help.
replace_once(
    "checks/litespeed.sh",
    dedent(r'''\
    _preflight() {
      local site="$1"
      if ! _wp_bootstrap_ok "$site"; then printf 'ERROR\tWordPress/WP-CLI bootstrap failed\n'; return; fi
      if ! _lscwp_installed "$site"; then printf 'SKIP\tLiteSpeed Cache is not installed\n'; return; fi
      if ! _lscwp_active "$site"; then printf 'SKIP\tLiteSpeed Cache is installed but inactive\n'; return; fi
      if [ -n "$LS_FAMILY" ] && ! _family_available "$site" "$LS_FAMILY" "$LS_SUB"; then
        printf 'ERROR\tLiteSpeed command unavailable: litespeed-%s %s\n' "$LS_FAMILY" "$LS_SUB"; return
      fi
      printf 'READY\tLiteSpeed Cache %s\n' "$(_lscwp_version "$site" || printf unknown)"
    }
    '''),
    dedent(r'''\
    _preflight() {
      local site="$1" probe_sub="$LS_SUB"
      # `database status` is a PressWarden inventory action, not a LiteSpeed
      # subcommand. Probe a real, representative command so status never calls
      # the nonexistent `wp help litespeed-database status`.
      if [ "$LS_FAMILY" = database ] && [ "$probe_sub" = status ]; then
        probe_sub=optimize_all
      fi
      if ! _wp_bootstrap_ok "$site"; then printf 'ERROR\tWordPress/WP-CLI bootstrap failed\n'; return; fi
      if ! _lscwp_installed "$site"; then printf 'SKIP\tLiteSpeed Cache is not installed\n'; return; fi
      if ! _lscwp_active "$site"; then printf 'SKIP\tLiteSpeed Cache is installed but inactive\n'; return; fi
      if [ -n "$LS_FAMILY" ] && ! _family_available "$site" "$LS_FAMILY" "$probe_sub"; then
        printf 'ERROR\tLiteSpeed command unavailable: litespeed-%s %s\n' "$LS_FAMILY" "$probe_sub"; return
      fi
      printf 'READY\tLiteSpeed Cache %s\n' "$(_lscwp_version "$site" || printf unknown)"
    }
    '''),
)

replace_once(
    "checks/litespeed.sh",
    dedent(r'''\
    _database_status() {
      local site label row state detail ready=0 skipped=0 failed=0
      require_wp; discover_sites
    '''),
    dedent(r'''\
    _database_status() {
      local site label row state detail ready=0 skipped=0 failed=0
      require_wp; discover_sites
      printf 'LiteSpeed database command status — %s discovered WordPress installation(s)\n\n' "${#WP_SITES[@]}"
    '''),
)

# 2. Replace the dedicated database helper with one implementation used both
# by the standalone command and DB/FULL maintenance suites.
write(
    "checks/litespeed-db.sh",
    dedent(r'''\
    #!/usr/bin/env bash
    # litespeed-db — LiteSpeed Cache database cleanup/optimization.
    #
    # LiteSpeed's litespeed-database command family does not accept normal
    # WP-CLI global parameters. Every real cleanup invocation therefore runs
    # from the WordPress directory with no --path/--skip-*/--no-color flags.
    set -uo pipefail
    NAME=litespeed-db
    DESC="LiteSpeed Cache database cleanup and optimization"
    SCAN_DOES="Checks LiteSpeed Cache database-command availability and runs optimize_all for eligible WordPress installations."
    SCAN_WHY="LiteSpeed can remove revisions, drafts, trash, comments, trackbacks, transients and other database clutter before PressWarden performs native SQL table maintenance."
    . "$(cd "$(dirname "$0")/.." && pwd)/lib/_lib.sh"

    SUITE_MODE="${PW_LITESPEED_DB_SUITE:-0}"
    ACTION="${1:-status}"
    if [ "$#" -eq 0 ] && [ "$SUITE_MODE" = 1 ]; then ACTION=optimize; fi
    case "$ACTION" in
      status|optimize) : ;;
      *) printf 'Use litespeed-db status or litespeed-db optimize.\n' >&2; exit 2 ;;
    esac

    _suite_cleanup_enabled() {
      case "${PRESSWARDEN_LITESPEED_DB_MAINTENANCE:-1}" in
        0|false|FALSE|no|NO|off|OFF) return 1 ;;
        *) return 0 ;;
      esac
    }

    if [ "$SUITE_MODE" = 1 ] && ! _suite_cleanup_enabled; then
      printf 'LiteSpeed database cleanup — SKIP (PRESSWARDEN_LITESPEED_DB_MAINTENANCE=0)\n'
      exit 0
    fi

    # Built-in WP-CLI commands may use normal global parameters because they do
    # not invoke the exceptional LiteSpeed database command family.
    _wp_builtin() {
      local site="$1"; shift
      wp "$@" --path="$site" --skip-plugins --skip-themes --skip-packages --no-color
    }
    _wp_bootstrap_ok() { _wp_builtin "$1" core is-installed >/dev/null 2>&1; }
    _lscwp_installed() { _wp_builtin "$1" plugin is-installed litespeed-cache >/dev/null 2>&1; }
    _lscwp_active() { _wp_builtin "$1" plugin is-active litespeed-cache >/dev/null 2>&1; }
    _lscwp_command_available() {
      local site="$1"
      (cd "$site" 2>/dev/null && PAGER=cat WP_CLI_PAGER=cat wp help litespeed-database optimize_all >/dev/null 2>&1)
    }
    _is_multisite() { _wp_builtin "$1" core is-installed --network >/dev/null 2>&1; }

    # Print one validated positive blog ID per line. The full list is validated
    # before any multisite cleanup begins, so malformed/partial inventory cannot
    # lead to a false network-wide success claim.
    _multisite_blog_ids() {
      local site="$1" raw id clean seen='' count=0
      raw=$(_wp_builtin "$site" site list --field=blog_id 2>/dev/null) || return 1
      while IFS= read -r id; do
        clean="$id"
        clean="${clean#"${clean%%[![:space:]]*}"}"
        clean="${clean%"${clean##*[![:space:]]}"}"
        [ -n "$clean" ] || continue
        case "$clean" in *[!0-9]*) return 1 ;; esac
        [ "$clean" -gt 0 ] 2>/dev/null || return 1
        case " $seen " in *" $clean "*) continue ;; esac
        printf '%s\n' "$clean"
        seen="$seen $clean"
        count=$((count+1))
      done <<< "$raw"
      [ "$count" -gt 0 ]
    }

    # `wp db size --size_format=b` is best-effort telemetry. Failure to measure
    # allocation never blocks cleanup or changes the maintenance verdict.
    _db_size_bytes() {
      local site="$1" n
      n=$(_wp_builtin "$site" db size --size_format=b 2>/dev/null | tr -d '[:space:]') || return 1
      case "$n" in ''|*[!0-9]*) return 1 ;; esac
      printf '%s' "$n"
    }

    _format_bytes() {
      awk -v n="${1:-0}" 'BEGIN {
        split("B KB MB GB TB", u, " "); i=1;
        while (n >= 1024 && i < 5) { n/=1024; i++ }
        if (i == 1) printf "%.0f %s", n, u[i];
        else if (n >= 100) printf "%.0f %s", n, u[i];
        else if (n >= 10) printf "%.1f %s", n, u[i];
        else printf "%.2f %s", n, u[i];
      }'
    }

    _preflight_site() {
      # Prints STATE<TAB>DETAIL where STATE is READY, SKIP, or ERROR.
      local site="$1" ids count
      if ! _wp_bootstrap_ok "$site"; then
        printf 'ERROR\tWordPress/WP-CLI bootstrap failed\n'
        return 0
      fi
      if ! _lscwp_installed "$site"; then
        printf 'SKIP\tLiteSpeed Cache is not installed\n'
        return 0
      fi
      if ! _lscwp_active "$site"; then
        printf 'SKIP\tLiteSpeed Cache is installed but inactive\n'
        return 0
      fi
      if ! _lscwp_command_available "$site"; then
        printf 'ERROR\tLiteSpeed Cache is active but litespeed-database optimize_all is unavailable\n'
        return 0
      fi
      if _is_multisite "$site"; then
        ids=$(_multisite_blog_ids "$site") || {
          printf 'ERROR\tmultisite blog-ID inventory failed; no cleanup will be attempted\n'
          return 0
        }
        count=$(printf '%s\n' "$ids" | awk 'NF { n++ } END { print n+0 }')
        printf 'READY\tmultisite detected; %s validated blog(s) will be cleaned\n' "$count"
      else
        printf 'READY\tLiteSpeed optimize_all available\n'
      fi
    }

    _show_command_output() {
      local file="$1"
      [ -s "$file" ] || return 0
      tr -d '\r' < "$file" | head -12 | sed 's/^/        /'
    }

    _confirm_optimize() {
      local count="$1" ans=''
      [ "$SUITE_MODE" = 1 ] && return 0
      [ "${PRESSWARDEN_INTERACTIVE:-1}" = 0 ] && return 0
      if [ -r /dev/tty ] && [ -w /dev/tty ]; then
        printf '\n  Run LiteSpeed optimize_all for %s eligible WordPress installation(s) under %s? [y/N]: ' "$count" "$ROOT" > /dev/tty
        IFS= read -r ans < /dev/tty || ans=''
        case "$ans" in y|Y|yes|YES) return 0 ;; *) printf 'Cancelled.\n'; return 1 ;; esac
      fi
      printf 'Refusing LiteSpeed database optimization without an interactive terminal. Set PRESSWARDEN_INTERACTIVE=0 only for intentional automation.\n' >&2
      return 1
    }

    # Result globals for one installation.
    LSDB_RUN_BLOG_TOTAL=1
    LSDB_RUN_BLOG_DONE=0
    LSDB_RUN_FAILED_BLOG=''
    LSDB_RUN_ENUM_FAILED=0

    _run_site_optimization() {
      local site="$1" multisite="$2" out="$3" ids blog rc
      local -a blogs=()
      LSDB_RUN_BLOG_TOTAL=1
      LSDB_RUN_BLOG_DONE=0
      LSDB_RUN_FAILED_BLOG=''
      LSDB_RUN_ENUM_FAILED=0

      if [ "$multisite" = 1 ]; then
        ids=$(_multisite_blog_ids "$site") || {
          printf 'Multisite blog-ID inventory failed before cleanup; no blog was changed.\n' > "$out"
          LSDB_RUN_ENUM_FAILED=1
          return 96
        }
        while IFS= read -r blog; do [ -n "$blog" ] && blogs+=("$blog"); done <<< "$ids"
        [ "${#blogs[@]}" -gt 0 ] || {
          printf 'Multisite blog-ID inventory was empty; no blog was changed.\n' > "$out"
          LSDB_RUN_ENUM_FAILED=1
          return 96
        }
        LSDB_RUN_BLOG_TOTAL=${#blogs[@]}
        : > "$out" || return 97
        for blog in "${blogs[@]}"; do
          printf 'Blog %s:\n' "$blog" >> "$out"
          # Do not add WP-CLI global parameters here.
          (cd "$site" && wp litespeed-database optimize_all blog "$blog") >> "$out" 2>&1
          rc=$?
          if [ "$rc" -ne 0 ]; then
            LSDB_RUN_FAILED_BLOG="$blog"
            return "$rc"
          fi
          LSDB_RUN_BLOG_DONE=$((LSDB_RUN_BLOG_DONE+1))
        done
        return 0
      fi

      # Do not add WP-CLI global parameters here.
      (cd "$site" && wp litespeed-database optimize_all) > "$out" 2>&1
      rc=$?
      [ "$rc" -ne 0 ] || LSDB_RUN_BLOG_DONE=1
      return "$rc"
    }

    LSDB_PHASE=''
    _lsdb_interrupt() {
      trap - INT TERM
      if [ "$LSDB_PHASE" = preflight ]; then
        printf '\nInterrupted during LiteSpeed database preflight; no databases were changed.\n' >&2
      elif [ "$LSDB_PHASE" = optimize ]; then
        printf '\nInterrupted during LiteSpeed database optimization; installations and multisite blogs already completed remain optimized.\n' >&2
      else
        printf '\nLiteSpeed database operation interrupted.\n' >&2
      fi
      exit 130
    }

    _status() {
      local site label row state detail ready=0 skipped=0 failed=0 multisite=0 idx=0 total
      require_wp; discover_sites
      total=${#WP_SITES[@]}
      printf 'LiteSpeed database maintenance status — %s discovered WordPress installation(s)\n\n' "$total"
      for site in "${WP_SITES[@]}"; do
        idx=$((idx+1))
        label=$(site_label_from_root "$site")
        row=$(_preflight_site "$site")
        IFS=$'\t' read -r state detail <<< "$row"
        case "$state" in
          READY)
            ready=$((ready+1))
            [[ "$detail" == multisite* ]] && multisite=$((multisite+1))
            printf '  [%3d/%3d] ✓ %-34s READY  %s\n' "$idx" "$total" "$label" "$detail"
            ;;
          SKIP)
            skipped=$((skipped+1))
            printf '  [%3d/%3d] - %-34s SKIP   %s\n' "$idx" "$total" "$label" "$detail"
            ;;
          *)
            failed=$((failed+1))
            printf '  [%3d/%3d] ✖ %-34s ERROR  %s\n' "$idx" "$total" "$label" "$detail"
            ;;
        esac
      done
      printf '\nSummary: ready %s • skipped %s • errors %s' "$ready" "$skipped" "$failed"
      [ "$multisite" -eq 0 ] || printf ' • multisite installations %s' "$multisite"
      printf '\n'
      [ "$failed" -eq 0 ] || return 2
    }

    _optimize() {
      local site label row state detail out rc before after delta elapsed started ended is_multi scope_desc
      local ready=0 skipped=0 preflight_failed=0 optimized=0 failed=0 multisite=0
      local idx=0 total exec_idx=0 exec_total measured=0 reduced_sites=0 unchanged_sites=0 increased_sites=0
      local total_before=0 total_after=0 total_delta=0 completed_blog_scopes=0
      local -a eligible=() eligible_multisite=()
      require_wp; discover_sites
      total=${#WP_SITES[@]}

      trap _lsdb_interrupt INT TERM
      LSDB_PHASE=preflight
      printf 'LiteSpeed database optimization preflight — %s discovered WordPress installation(s)\n' "$total"
      printf 'Action: wp litespeed-database optimize_all [blog <id>]\n'
      if [ "$SUITE_MODE" = 1 ]; then
        printf 'Mode: DB maintenance suite (runs before native SQL table maintenance).\n'
      else
        printf 'This is LiteSpeed Cache full database cleanup/optimization, not only SQL table optimization.\n'
      fi
      printf '\n'

      for site in "${WP_SITES[@]}"; do
        idx=$((idx+1))
        label=$(site_label_from_root "$site")
        row=$(_preflight_site "$site")
        IFS=$'\t' read -r state detail <<< "$row"
        case "$state" in
          READY)
            ready=$((ready+1)); eligible+=("$site")
            if [[ "$detail" == multisite* ]]; then
              multisite=$((multisite+1)); eligible_multisite+=("1")
            else
              eligible_multisite+=("0")
            fi
            printf '  [%3d/%3d] ✓ %-34s READY  %s\n' "$idx" "$total" "$label" "$detail"
            ;;
          SKIP)
            skipped=$((skipped+1))
            printf '  [%3d/%3d] - %-34s SKIP   %s\n' "$idx" "$total" "$label" "$detail"
            ;;
          *)
            preflight_failed=$((preflight_failed+1))
            printf '  [%3d/%3d] ✖ %-34s ERROR  %s\n' "$idx" "$total" "$label" "$detail"
            ;;
        esac
      done

      printf '\nPreflight complete: ready %s • skipped %s • errors %s\n' "$ready" "$skipped" "$preflight_failed"
      if [ "${#eligible[@]}" -eq 0 ]; then
        printf 'No eligible LiteSpeed Cache sites found; nothing changed.\n'
        trap - INT TERM
        LSDB_PHASE=''
        [ "$preflight_failed" -eq 0 ] || return 2
        return 0
      fi

      _confirm_optimize "${#eligible[@]}" || { trap - INT TERM; LSDB_PHASE=''; return 1; }

      LSDB_PHASE=optimize
      exec_total=${#eligible[@]}
      printf '\nRunning LiteSpeed database optimization sequentially...\n'
      for site in "${eligible[@]}"; do
        exec_idx=$((exec_idx+1))
        label=$(site_label_from_root "$site")
        is_multi=${eligible_multisite[$((exec_idx-1))]}
        before=$(_db_size_bytes "$site" 2>/dev/null || true)
        out=$(tmpf)
        started=$(date +%s)
        _run_site_optimization "$site" "$is_multi" "$out"
        rc=$?
        ended=$(date +%s); elapsed=$((ended-started))
        completed_blog_scopes=$((completed_blog_scopes+LSDB_RUN_BLOG_DONE))

        if [ "$rc" -eq 0 ]; then
          optimized=$((optimized+1))
          after=$(_db_size_bytes "$site" 2>/dev/null || true)
          if [ "$is_multi" = 1 ]; then scope_desc="${LSDB_RUN_BLOG_TOTAL} blogs"; else scope_desc='single site'; fi
          if [ -n "$before" ] && [ -n "$after" ]; then
            measured=$((measured+1)); total_before=$((total_before+before)); total_after=$((total_after+after)); delta=$((before-after))
            if [ "$delta" -gt 0 ]; then
              reduced_sites=$((reduced_sites+1))
              printf '  [%3d/%3d] ✓ %-34s OPTIMIZED  %s • %s → %s • reported reduction %s  (%ss)\n' "$exec_idx" "$exec_total" "$label" "$scope_desc" "$(_format_bytes "$before")" "$(_format_bytes "$after")" "$(_format_bytes "$delta")" "$elapsed"
            elif [ "$delta" -eq 0 ]; then
              unchanged_sites=$((unchanged_sites+1))
              printf '  [%3d/%3d] ✓ %-34s OPTIMIZED  %s • %s → %s • no reported size change  (%ss)\n' "$exec_idx" "$exec_total" "$label" "$scope_desc" "$(_format_bytes "$before")" "$(_format_bytes "$after")" "$elapsed"
            else
              increased_sites=$((increased_sites+1)); delta=$((-delta))
              printf '  [%3d/%3d] ✓ %-34s OPTIMIZED  %s • %s → %s • reported increase %s  (%ss)\n' "$exec_idx" "$exec_total" "$label" "$scope_desc" "$(_format_bytes "$before")" "$(_format_bytes "$after")" "$(_format_bytes "$delta")" "$elapsed"
            fi
          else
            printf '  [%3d/%3d] ✓ %-34s OPTIMIZED  %s • database size unavailable  (%ss)\n' "$exec_idx" "$exec_total" "$label" "$scope_desc" "$elapsed"
          fi
          _show_command_output "$out"
        else
          failed=$((failed+1))
          if [ "$is_multi" = 1 ] && [ "$LSDB_RUN_ENUM_FAILED" -eq 1 ]; then
            printf '  [%3d/%3d] ✖ %-34s FAILED  multisite inventory; no blog changed  (%ss)\n' "$exec_idx" "$exec_total" "$label" "$elapsed"
          elif [ "$is_multi" = 1 ]; then
            printf '  [%3d/%3d] ✖ %-34s FAILED  blog %s; %s/%s blog(s) completed • exit %s  (%ss)\n' "$exec_idx" "$exec_total" "$label" "${LSDB_RUN_FAILED_BLOG:-unknown}" "$LSDB_RUN_BLOG_DONE" "$LSDB_RUN_BLOG_TOTAL" "$rc" "$elapsed"
          else
            printf '  [%3d/%3d] ✖ %-34s FAILED  exit %s  (%ss)\n' "$exec_idx" "$exec_total" "$label" "$rc" "$elapsed"
          fi
          _show_command_output "$out"
        fi
        rm -f "$out"
      done

      trap - INT TERM
      LSDB_PHASE=''
      printf '\nLiteSpeed database optimization complete.\n'
      printf 'Summary: optimized installations %s • completed blog scopes %s • skipped %s • preflight errors %s • execution failures %s\n' "$optimized" "$completed_blog_scopes" "$skipped" "$preflight_failed" "$failed"
      if [ "$measured" -gt 0 ]; then
        total_delta=$((total_before-total_after))
        printf 'Measured database size (%s installation(s)): %s → %s' "$measured" "$(_format_bytes "$total_before")" "$(_format_bytes "$total_after")"
        if [ "$total_delta" -gt 0 ]; then
          printf ' • reported reduction %s' "$(_format_bytes "$total_delta")"
        elif [ "$total_delta" -eq 0 ]; then
          printf ' • no reported aggregate size change'
        else
          total_delta=$((-total_delta)); printf ' • reported increase %s' "$(_format_bytes "$total_delta")"
        fi
        printf '\n'
        printf 'Size results: reduced %s • unchanged %s • increased %s\n' "$reduced_sites" "$unchanged_sites" "$increased_sites"
        printf 'Note: database allocation can stay unchanged or grow after rows are cleaned; these are size measurements, not deleted-record counts.\n'
      fi
      [ "$preflight_failed" -eq 0 ] && [ "$failed" -eq 0 ] || return 2
    }

    case "$ACTION" in
      status) _status ;;
      optimize) _optimize ;;
    esac
    '''),
)

# 3. Make LiteSpeed cleanup part of every suite that advertises DB maintenance.
write(
    "suites/db.sh",
    dedent(r'''\
    #!/usr/bin/env bash
    RUN_NAME=db
    RUN_DESC="database only • security/isolation + malware persistence audit → LiteSpeed cleanup → conditional repair → optimize → verify"
    RUN_DOES="Runs database security/isolation checks, targeted stored-malware and suspicious administrator-persistence intelligence, LiteSpeed Cache cleanup where active, then conditional native table repair, optimization, and final verification."
    RUN_WHY="Use when you want database posture, stored-threat inspection, cleanup, and health without scanning the WordPress filesystem."
    unset PRESSWARDEN_SKIP_DB_PRIV_SCOPE PRESSWARDEN_SKIP_DB_CRED_REUSE 2>/dev/null || true
    PW_LITESPEED_DB_SUITE=1
    export PW_LITESPEED_DB_SUITE
    CHECKS="wp-db wp-db-malware litespeed-db wp-db-maintenance"
    . "$(cd "$(dirname "$0")/.." && pwd)/lib/_runner.sh"
    run_all
    '''),
)

write(
    "suites/full.sh",
    dedent(r'''\
    #!/usr/bin/env bash
    RUN_NAME=full
    RUN_DESC="comprehensive sweep • hardening + deep PHP/image scans + threat intelligence + official integrity + LiteSpeed/native DB maintenance"
    RUN_DOES="Runs the complete local security suite, including recursive permissions, deep PHP/image inspection, PHP/JavaScript/campaign/database-malware intelligence, WordPress policy, optional external YARA rules, official integrity checks, optional Wordfence/Patchstack/WPScan vulnerability intelligence, and LiteSpeed plus native database maintenance."
    RUN_WHY="Use periodically or after an incident when slower exhaustive checks, network-backed intelligence, optional organization-supplied signatures, and repair operations are justified."
    unset PRESSWARDEN_SKIP_DB_PRIV_SCOPE PRESSWARDEN_SKIP_DB_CRED_REUSE 2>/dev/null || true
    PW_LITESPEED_DB_SUITE=1
    export PW_LITESPEED_DB_SUITE
    CHECKS="host-persistence filesystem-security-full htcheck confcheck php-runtime phpcheck sensitive-files wp-access wp-settings wp-core wp-root wp-plugins wp-themes wp-uploads phpdeep php-obfuscated-loader php-threat-intel wp-campaign-intel js-threat-intel external-yara wp-plugin-integrity wp-wordfence-intel wp-patchstack-intel wp-vulnerabilities wp-uploads-deep wp-db wp-db-malware litespeed-db wp-db-maintenance"
    . "$(cd "$(dirname "$0")/.." && pwd)/lib/_runner.sh"
    run_all
    '''),
)

# 4. A write-capable LiteSpeed cleanup interrupted in-flight is no safer to
# replay than native wp-db-maintenance.
replace_once(
    "lib/run-continuation.php",
    "    if($missing['check']==='wp-db-maintenance')pwc_fail('the interrupted check performs automatic database writes; rerun the DB/full suite explicitly instead of replaying it');\n",
    "    if(in_array($missing['check'],['litespeed-db','wp-db-maintenance'],true))pwc_fail('the interrupted check performs automatic database writes; rerun the DB/full suite explicitly instead of replaying it');\n",
)

continuation_anchor = dedent(r'''\
# Scope metadata remains allowlisted/private; unrelated environment secrets are never captured.
''')
continuation_case = dedent(r'''\
# LiteSpeed optimize_all is also write-capable and must never be replayed after
# an interruption at that step.
LSDBID='db-20260916-120000.LSDB01'
php "$STATE" init "$RUNS" "$LSDBID" db 1.1.22 "$TMP/root" 1 1 3 complete 12345 'wp-db litespeed-db wp-db-maintenance' "$TMP/lsdb.log" 1789574400
php "$CONT" capture "$RUNS/$LSDBID" "$SCOPE"
php "$STATE" step "$RUNS/$LSDBID/state.json" 1 3 wp-db
php "$STATE" result "$RUNS/$LSDBID/state.json" wp-db clean 0 2
php "$STATE" step "$RUNS/$LSDBID/state.json" 2 3 litespeed-db
php "$STATE" interrupt "$RUNS/$LSDBID/state.json" HUP 129 litespeed-db
set +e; php "$CONT" plan "$RUNS" "$LSDBID" 1.1.22 > "$TMP/lsdb.out" 2>&1; rc=$?; set -e
[ "$rc" -eq 2 ]; grep -q 'automatic database writes' "$TMP/lsdb.out"

''')
replace_once("tests/run-continuation.sh", continuation_anchor, continuation_case + continuation_anchor)

# 5. Tighten full LiteSpeed CLI mocks: only documented database subcommands are
# accepted, so a future accidental `status` probe fails regression tests.
replace_once(
    "tests/litespeed-full-cli.sh",
    dedent(r'''\
      help)
        case "${2:-}" in litespeed-option|litespeed-purge|litespeed-presets|litespeed-image|litespeed-online|litespeed-debug|litespeed-crawler|litespeed-database) exit 0 ;; *) exit 93 ;; esac
        ;;
    '''),
    dedent(r'''\
      help)
        case "${2:-}" in
          litespeed-database)
            case "${3:-}" in
              ''|clear_posts|clear_comments|clear_trackbacks|clear_transients|optimize_tables|optimize_all) exit 0 ;;
              *) exit 93 ;;
            esac
            ;;
          litespeed-option|litespeed-purge|litespeed-presets|litespeed-image|litespeed-online|litespeed-debug|litespeed-crawler) exit 0 ;;
          *) exit 93 ;;
        esac
        ;;
    '''),
)
replace_once(
    "tests/litespeed-full-cli.sh",
    "run_check database status > /dev/null\n",
    "run_check database status > \"$T/database-status\"\ngrep -q 'example.com.*READY' \"$T/database-status\"\n! grep -q 'litespeed-database status' \"$T/database-status\"\n",
)

# 6. Expand dedicated LiteSpeed DB tests for multisite coverage, suite mode,
# disabling, and exact no-global-argument invocation.
replace_once(
    "tests/litespeed-db.sh",
    dedent(r'''\
      db)
        [ "${2:-}" = size ] || exit 89
        # Simulate measurable allocation reduction after LiteSpeed optimization.
        if [ -f "$p/.optimized" ]; then echo 900000; else echo 1000000; fi
        ;;
      litespeed-database)
        [ "${2:-}" = optimize_all ] || exit 97
        [ -f "$p/.litespeed-active" ] || exit 98
        [ ! -f "$p/.optimize-fail" ] || { echo 'simulated LiteSpeed optimization failure' >&2; exit 41; }
        touch "$p/.optimized"
        echo 'Success: LiteSpeed database optimized.'
        ;;
    '''),
    dedent(r'''\
      site)
        [ "${2:-}" = list ] || exit 88
        [ -f "$p/.multisite" ] || exit 89
        [ "${3:-}" = --field=blog_id ] || exit 87
        if [ -f "$p/.bad-blog-list" ]; then printf '1\nbad\n'; else printf '1\n2\n'; fi
        ;;
      db)
        [ "${2:-}" = size ] || exit 89
        # Simulate measurable allocation reduction after LiteSpeed optimization.
        if [ -f "$p/.optimized" ]; then echo 900000; else echo 1000000; fi
        ;;
      litespeed-database)
        [ "${2:-}" = optimize_all ] || exit 97
        [ -f "$p/.litespeed-active" ] || exit 98
        [ ! -f "$p/.optimize-fail" ] || { echo 'simulated LiteSpeed optimization failure' >&2; exit 41; }
        if [ -f "$p/.multisite" ]; then
          [ "${3:-}" = blog ] || exit 86
          case "${4:-}" in ''|*[!0-9]*) exit 85 ;; esac
          printf '%s\n' "$4" >> "$p/.optimized-blogs"
        else
          [ "$#" -eq 2 ] || exit 84
        fi
        touch "$p/.optimized"
        echo 'Success: LiteSpeed database optimized.'
        ;;
    '''),
)

replace_once(
    "tests/litespeed-db.sh",
    "grep -q 'Measured database size (1 site(s))' \"$T/optimized\"\n",
    "grep -q 'Measured database size (1 installation(s))' \"$T/optimized\"\n",
)

replace_once(
    "tests/litespeed-db.sh",
    dedent(r'''\
# Multisite is permitted but explicitly warned because optimize_all without
# `blog <id>` does not establish network-wide cleanup coverage. Size savings are
# also deliberately not claimed for the whole shared multisite database.
rm -f "$T/sites/example.com/public_html/.optimize-fail"
touch "$T/sites/example.com/public_html/.multisite"
run litespeed-db status example.com > "$T/multisite" 2>&1
grep -q 'multisite detected' "$T/multisite"
grep -q 'does not claim full multisite-network cleanup' "$T/multisite"
run litespeed-db optimize example.com > "$T/multisite-optimize" 2>&1
grep -q 'size statistics skipped for multisite' "$T/multisite-optimize"

printf 'LiteSpeed database maintenance: targeting, exact CLI invocation, progress, size statistics, failures and multisite warning PASS\n'
    '''),
    dedent(r'''\
# Multisite inventory is validated before cleanup, then every blog ID is passed
# explicitly to LiteSpeed without ordinary WP-CLI global parameters.
rm -f "$T/sites/example.com/public_html/.optimize-fail" "$T/sites/example.com/public_html/.optimized" "$T/sites/example.com/public_html/.optimized-blogs"
touch "$T/sites/example.com/public_html/.multisite"
run litespeed-db status example.com > "$T/multisite" 2>&1
grep -q 'multisite detected; 2 validated blog(s)' "$T/multisite"
run litespeed-db optimize example.com > "$T/multisite-optimize" 2>&1
printf '1\n2\n' > "$T/expected-blogs"
sort -nu "$T/sites/example.com/public_html/.optimized-blogs" > "$T/actual-blogs"
diff -u "$T/expected-blogs" "$T/actual-blogs"
grep -q 'OPTIMIZED.*2 blogs' "$T/multisite-optimize"
grep -q 'Measured database size (1 installation(s))' "$T/multisite-optimize"

# Malformed multisite inventory is an error and no blog is changed.
rm -f "$T/sites/example.com/public_html/.optimized" "$T/sites/example.com/public_html/.optimized-blogs"
touch "$T/sites/example.com/public_html/.bad-blog-list"
if run litespeed-db status example.com > "$T/bad-blogs" 2>&1; then
  echo 'malformed multisite inventory unexpectedly succeeded' >&2; exit 1
fi
grep -q 'blog-ID inventory failed' "$T/bad-blogs"
[ ! -f "$T/sites/example.com/public_html/.optimized" ]
rm -f "$T/sites/example.com/public_html/.bad-blog-list" "$T/sites/example.com/public_html/.multisite"

# DB/FULL suite mode runs optimize automatically without a second prompt, while
# the documented configuration switch can disable only the automatic suite step.
rm -f "$T/sites/example.com/public_html/.optimized"
PRESSWARDEN_SCAN_ROOT="$T/sites/example.com/public_html" PW_LITESPEED_DB_SUITE=1 \
  bash "$REPO/checks/litespeed-db.sh" > "$T/suite-mode" 2>&1
[ -f "$T/sites/example.com/public_html/.optimized" ]
grep -q 'Mode: DB maintenance suite' "$T/suite-mode"
rm -f "$T/sites/example.com/public_html/.optimized"
PRESSWARDEN_SCAN_ROOT="$T/sites/example.com/public_html" PW_LITESPEED_DB_SUITE=1 PRESSWARDEN_LITESPEED_DB_MAINTENANCE=0 \
  bash "$REPO/checks/litespeed-db.sh" > "$T/suite-disabled" 2>&1
[ ! -f "$T/sites/example.com/public_html/.optimized" ]
grep -q 'SKIP.*PRESSWARDEN_LITESPEED_DB_MAINTENANCE=0' "$T/suite-disabled"

grep -q 'CHECKS=.*litespeed-db wp-db-maintenance' "$REPO/suites/db.sh"
grep -q 'CHECKS=.*litespeed-db wp-db-maintenance' "$REPO/suites/full.sh"
grep -q 'PW_LITESPEED_DB_SUITE=1' "$REPO/suites/db.sh"
grep -q 'PW_LITESPEED_DB_SUITE=1' "$REPO/suites/full.sh"

printf 'LiteSpeed database maintenance: documented command probes, suite integration, multisite coverage, exact invocation, progress, statistics and failures PASS\n'
    '''),
)

# 7. Config, help text and operator docs.
replace_once(
    "config/config.example",
    dedent(r'''\
# Targeted database malware scan: candidate rows per source and total value bytes per site.
# Row values above 1 MiB are not fetched. Reaching a limit reports INCOMPLETE.
PRESSWARDEN_DB_MAX_ROWS=5000
PRESSWARDEN_DB_MAX_BYTES=33554432
    '''),
    dedent(r'''\
# Targeted database malware scan: candidate rows per source and total value bytes per site.
# Row values above 1 MiB are not fetched. Reaching a limit reports INCOMPLETE.
PRESSWARDEN_DB_MAX_ROWS=5000
PRESSWARDEN_DB_MAX_BYTES=33554432

# DB and FULL suites run LiteSpeed Cache optimize_all before native table
# repair/optimization when LiteSpeed Cache is active. Set 0 to keep that cleanup
# available only through the explicit `litespeed-db optimize` command.
PRESSWARDEN_LITESPEED_DB_MAINTENANCE=1
    '''),
)

replace_once(
    "presswarden",
    "  ./presswarden db [target]            Database security/malware audit + maintenance\n",
    "  ./presswarden db [target]            Database security/malware audit + LiteSpeed/native maintenance\n",
)

write(
    "docs/LITESPEED-DATABASE.md",
    dedent(r'''\
    # LiteSpeed Database Maintenance

    PressWarden supports both focused LiteSpeed database cleanup and automatic integration with its write-capable database-maintenance suites.

    ## Focused commands

    Check which discovered sites can use LiteSpeed database optimization:

    ```bash
    presswarden litespeed-db status [target]
    ```

    Run LiteSpeed Cache's full database cleanup/optimization:

    ```bash
    presswarden litespeed-db optimize [target]
    ```

    `target` follows normal PressWarden targeting: a website name, nested website name, directory, `all`, or the configured fleet when omitted.

    ## DB and FULL suite integration

    `presswarden db` and `presswarden full` now run the same `litespeed-db` maintenance implementation immediately before PressWarden's native SQL table check/repair/optimization step.

    The automatic step:

    - runs only where LiteSpeed Cache is installed, active, and exposes `litespeed-database optimize_all`;
    - skips sites without an active LiteSpeed Cache plugin;
    - runs installations sequentially to limit load;
    - reports active-plugin/command/bootstrap failures as incomplete maintenance rather than false success;
    - continues to native table maintenance even when one independent LiteSpeed site fails.

    Disable only the automatic suite step with:

    ```bash
    PRESSWARDEN_LITESPEED_DB_MAINTENANCE=0 presswarden db
    ```

    The explicit `litespeed-db optimize` command remains available even when that suite setting is disabled.

    ## Exact command behavior

    For a normal single-site installation, PressWarden changes into the WordPress directory and runs exactly:

    ```bash
    wp litespeed-database optimize_all
    ```

    LiteSpeed's database command family is the exception to its usual WP-CLI behavior and does not accept ordinary global parameters. PressWarden never appends `--path`, `--skip-plugins`, `--skip-themes`, `--skip-packages`, or `--no-color` to the real cleanup command.

    `presswarden litespeed database status` is a PressWarden-only inventory action. It validates the real `optimize_all` subcommand and never tries to execute or request help for a nonexistent `litespeed-database status` command.

    ## Multisite

    Before changing a multisite installation, PressWarden obtains all blog IDs with the built-in WP-CLI site inventory, validates the complete list, and then runs:

    ```bash
    wp litespeed-database optimize_all blog ID
    ```

    once for each validated ID. If the inventory is empty, malformed, or cannot be read, no blog cleanup starts and the installation is reported as an error. If one blog fails during execution, already-completed blog cleanups remain complete and the partial result is reported explicitly.

    The lower-level umbrella command still permits a deliberately selected blog:

    ```bash
    presswarden litespeed database optimize-all --blog=2 --target example.com
    ```

    ## Reporting

    Preflight and execution display `[current/total]` progress. Successful runs show the number of completed blog scopes, elapsed time, bounded LiteSpeed output, and best-effort database allocation before and after cleanup.

    Allocation figures are not deleted-row counts. MySQL may retain allocated space after rows are removed, and normal activity can make the measured database grow during maintenance. A successful cleanup may therefore report no size reduction.

    ## Safety behavior

    Focused interactive optimization requires confirmation. `PRESSWARDEN_INTERACTIVE=0` is treated as intentional automation. The `db` and `full` commands are already explicit write-capable maintenance suites, so their internal LiteSpeed step does not prompt a second time.

    An interrupted `litespeed-db` suite step is non-replayable through `presswarden continue`, just like `wp-db-maintenance`. Run a fresh `db` or `full` suite after reviewing the database state.

    ## Scheduled cleanup

    Weekly maintenance is a reasonable starting point for many managed sites. A focused Sunday 3:00 AM example is:

    ```cron
    0 3 * * 0 PATH="$HOME/.local/bin:/usr/local/bin:/usr/bin:/bin" PRESSWARDEN_INTERACTIVE=0 /path/to/presswarden litespeed-db optimize all >> "$HOME/.local/state/presswarden/litespeed-db-cron.log" 2>&1
    ```

    To schedule the complete database security and maintenance workflow instead, substitute `presswarden db all`. Confirm WP-CLI and the desired PHP binary are available in the cron environment before enabling fleet execution.
    '''),
)

replace_once(
    "docs/LITESPEED.md",
    "LiteSpeed documents `litespeed-database` as the exception to its normal WP-CLI behavior: these commands do not accept standard WP-CLI global parameters. PressWarden therefore changes into each WordPress installation and executes the database command without `--path`, `--skip-plugins`, `--skip-themes`, or other global parameters.\n",
    "LiteSpeed documents `litespeed-database` as the exception to its normal WP-CLI behavior: these commands do not accept standard WP-CLI global parameters. PressWarden therefore changes into each WordPress installation and executes the database command without `--path`, `--skip-plugins`, `--skip-themes`, or other global parameters.\n\n`database status` is PressWarden inventory syntax, not a LiteSpeed subcommand. It checks availability using the documented `optimize_all` command and never probes `litespeed-database status`.\n\nThe `db` and `full` suites automatically run the dedicated `litespeed-db` cleanup before native SQL table maintenance. On multisite they validate all blog IDs first and run `optimize_all blog ID` for each. Set `PRESSWARDEN_LITESPEED_DB_MAINTENANCE=0` to disable only this automatic suite step.\n",
)

replace_once(
    "docs/DATABASE-SCANNING.md",
    "PressWarden 1.1.5 inspects candidate `options`, `posts`, and current-blog administrator role metadata through the existing WordPress database handle. SQL issued by this check is SELECT-only: no repair, deletion, normalization or option updates. The broader `db` and `full` suites still contain their separate maintenance checks; this does not change those workflows.\n",
    "PressWarden inspects candidate `options`, `posts`, and current-blog administrator role metadata through the existing WordPress database handle. SQL issued by this threat-inspection check is SELECT-only: no repair, deletion, normalization or option updates. The write-capable `db` and `full` suites separately run LiteSpeed Cache cleanup where eligible, followed by native table check/conditional repair/optimization; those maintenance steps do not weaken the read-only guarantees of this inspection layer.\n",
)

replace_once(
    "docs/CONTINUATION.md",
    "- the interrupted step is `wp-db-maintenance`;\n",
    "- the interrupted step is `litespeed-db` or `wp-db-maintenance`;\n",
)
replace_once(
    "docs/CONTINUATION.md",
    "`wp-db-maintenance` can automatically repair genuinely unhealthy tables and runs `OPTIMIZE TABLE`. If the shell disappears during that write-capable step, PressWarden cannot prove exactly which database operation completed before interruption. It therefore refuses to replay that step through `continue`.\n",
    "`litespeed-db` can delete eligible WordPress database clutter and optimize tables, while `wp-db-maintenance` can repair genuinely unhealthy tables and runs `OPTIMIZE TABLE`. If the shell disappears during either write-capable step, PressWarden cannot prove exactly which blog/table operation completed before interruption. It therefore refuses to replay either step through `continue`.\n",
)

# README release/help wording.
replace_once("README.md", "![Version](https://img.shields.io/badge/version-1.1.19-2ea44f)", "![Version](https://img.shields.io/badge/version-1.1.22-2ea44f)")
replace_once(
    "README.md",
    "- 🗄️ **Database malware scanning** for stored scripts, PHP payloads, persistence, and suspicious administrator accounts\n",
    "- 🗄️ **Database malware scanning and maintenance** with stored-threat inspection, LiteSpeed cleanup, and native table verification\n",
)
replace_once(
    "README.md",
    "| `./presswarden db` | Database security, stored malware, and DB maintenance |\n",
    "| `./presswarden db` | Database security, stored malware, LiteSpeed cleanup, and native DB maintenance |\n",
)
replace_once(
    "README.md",
    "Automatic database maintenance is never replayed if it was the interrupted check.",
    "Automatic LiteSpeed or native database maintenance is never replayed if it was the interrupted check.",
)

# 8. Release metadata.
write("VERSION", "1.1.22\n")
changelog = read("CHANGELOG.md")
release = dedent(r'''\
## 1.1.22 — 2026-09-16

LiteSpeed database command correctness and suite integration.

- Fix `presswarden litespeed database status` so the PressWarden-only inventory action validates the documented `litespeed-database optimize_all` subcommand instead of probing the nonexistent `litespeed-database status` command.
- Tighten LiteSpeed command-matrix regression mocks so undocumented database subcommands fail, preventing pseudo-actions from being mistaken for plugin commands.
- Add the dedicated LiteSpeed cleanup implementation to both `db` and `full` immediately before native SQL table maintenance. Sites without active LiteSpeed Cache are skipped; active-plugin/bootstrap/command failures remain visible and make maintenance incomplete.
- Add `PRESSWARDEN_LITESPEED_DB_MAINTENANCE=0` as an opt-out for automatic suite cleanup while keeping explicit `litespeed-db optimize` available.
- Validate and enumerate every WordPress multisite blog ID before cleanup, then execute `optimize_all blog <id>` sequentially for each blog without unsupported WP-CLI global arguments. Malformed inventory starts no cleanup; partial per-blog failures are reported honestly.
- Preserve progress, bounded plugin output, elapsed time and best-effort before/after allocation statistics. Continue to avoid inventing deleted-row counts from database-size changes.
- Refuse safe continuation when interruption occurs inside either LiteSpeed or native database maintenance, because partially completed write operations cannot be replayed safely.
- Add focused single-site, multisite, suite-mode, opt-out, invalid-command, interruption and exact-invocation regressions.

''')
anchor = "All notable changes to PressWarden are documented here.\n\n"
if anchor not in changelog:
    raise SystemExit("CHANGELOG.md: release insertion anchor missing")
write("CHANGELOG.md", changelog.replace(anchor, anchor + release, 1))

# 9. CI coverage follows the expanded code surface.
replace_count(
    ".github/workflows/litespeed-db-quality.yml",
    "      - checks/litespeed-db.sh\n      - tests/litespeed-db.sh\n",
    "      - checks/litespeed-db.sh\n      - suites/db.sh\n      - suites/full.sh\n      - lib/run-continuation.php\n      - tests/litespeed-db.sh\n      - tests/run-continuation.sh\n",
    2,
)
replace_once(
    ".github/workflows/litespeed-db-quality.yml",
    "        run: bash -n presswarden checks/litespeed-db.sh tests/litespeed-db.sh\n",
    "        run: bash -n presswarden checks/litespeed-db.sh suites/db.sh suites/full.sh tests/litespeed-db.sh tests/run-continuation.sh\n",
)
replace_once(
    ".github/workflows/litespeed-full-quality.yml",
    "        run: bash -n presswarden checks/litespeed.sh checks/litespeed-db.sh tests/litespeed-full-cli.sh\n",
    "        run: bash -n presswarden checks/litespeed.sh checks/litespeed-db.sh suites/db.sh suites/full.sh tests/litespeed-full-cli.sh\n",
)

print("Applied PressWarden 1.1.22 LiteSpeed DB maintenance fixes.")
